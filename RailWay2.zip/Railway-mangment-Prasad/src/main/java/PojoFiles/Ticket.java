package PojoFiles;

import javax.persistence.JoinColumn;
import javax.persistence.*;

@Entity
@Table(name = "bookedTicket")
public class Ticket {
    @Id	
    	@GeneratedValue(strategy = GenerationType.AUTO)
    	private int id;
    	
    	@ManyToOne
	@JoinColumn(name = "user_id")
	private User user;
    	
    	private String source;
    	private String destination;
    	private String classs;
    	private String Date;
    	@Column(name = "_return")
    	private String Return;
    	
    	public Ticket() {
	    super();
	    // TODO Auto-generated constructor stub
	}

	public Ticket(User user, String source, String destination, String classs, String date, String return1) {
	    super();
	    this.user = user;
	    this.source = source;
	    this.destination = destination;
	    this.classs = classs;
	    Date = date;
	    Return = return1;
	}
    	
	public int getId() {
	    return id;
	}
	public void setId(int id) {
	    this.id = id;
	}
	public User getUser() {
	    return user;
	}
	public void setUser(User user) {
	    this.user = user;
	}
	public String getSource() {
	    return source;
	}
	public void setSource(String source) {
	    this.source = source;
	}
	public String getDestination() {
	    return destination;
	}
	public void setDestination(String destination) {
	    this.destination = destination;
	}
	public String getClasss() {
	    return classs;
	}
	public void setClasss(String classs) {
	    this.classs = classs;
	}
	public String getDate() {
	    return Date;
	}
	public void setDate(String date) {
	    Date = date;
	}
	public String getReturn() {
	    return Return;
	}
	public void setReturn(String return1) {
	    Return = return1;
	}
	
    	
	

}
